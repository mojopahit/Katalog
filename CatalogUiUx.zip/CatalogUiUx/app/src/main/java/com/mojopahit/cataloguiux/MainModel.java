package com.mojopahit.cataloguiux;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONException;
import org.json.JSONObject;

public class MainModel implements Parcelable {

    private String id, judul, deskripsi, rilis, foto, rating;

    public MainModel(JSONObject o) {
        try {
            String id = o.getString("id");
            String ttl = o.getString("title");
            String des = o.getString("overview");
            String rls = o.getString("release_date");
            String img = o.getString("poster_path");
            String rtg = o.getString("vote_average");

            this.id = id;
            this.judul = ttl;
            this.deskripsi = des;
            this.rilis = rls;
            this.foto = img;
            this.rating = rtg;
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getRilis() {
        return rilis;
    }

    public void setRilis(String rilis) {
        this.rilis = rilis;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.judul);
        dest.writeString(this.deskripsi);
        dest.writeString(this.rilis);
        dest.writeString(this.foto);
        dest.writeString(this.rating);
    }

    protected MainModel(Parcel in) {
        this.id = in.readString();
        this.judul = in.readString();
        this.deskripsi = in.readString();
        this.rilis = in.readString();
        this.foto = in.readString();
        this.rating = in.readString();
    }

    public static final Parcelable.Creator<MainModel> CREATOR = new Parcelable.Creator<MainModel>() {
        @Override
        public MainModel createFromParcel(Parcel source) {
            return new MainModel(source);
        }

        @Override
        public MainModel[] newArray(int size) {
            return new MainModel[size];
        }
    };
}